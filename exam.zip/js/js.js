﻿/*powered by GXG.ITC uther*/
var ans = new Array();
var user = new Array();
var qus = new Array();
var anss = new Array();
var data = new Array();
var page = 0,
	is_do = 1,
	type = 1,
	yname = '',
	ynum = 0,
	len = 100,
	passscore = 60,
	perscore = 1,
	countTimes = 1800,
	hasDone = 0,
	startCount = 0;
	timer = setInterval("countT()",1000);
$(function(){
	$.ajax({
		url:'/exam/admin/action.php?a=getcfg',
		type:'post',
		success:function(res){
			eval("var msg="+res);
			len=msg[0]
			for(i=0;i<msg[0];i++)
			{
				j=i+1;
				$(".all").append("<li>"+j+"</li>");
				$(".subject").append('<div class="sub" style="display:none;"><div class="ques"></div><ul class="ans"><li></li><li></li><li></li><li></li><div class="clear"></div></ul></div>');
			}
			$(".all li:first").addClass("grey");
			for(j=0;j<msg[1].length;j++)
			{
				$(".fp_type").append('<li><input type="radio" name="gxg_type" value="'+j+'" checked />'+msg[1][j]+'</li>');
			}
			if(msg[2]){passscore=msg[2];}
			if(msg[3]){perscore=msg[3];}
			if(msg[4]){countTimes=msg[4];}
		}
	});
	
	
	$("input[name=gxg_type]").on("change", function(){
		type = $(this).val();
	});
	$(".fp_start").click(function(){
		if(ynum == 0)
		{
			alert("请输入学号！");
			$(".ynum").focus();
			return false;
		}
		if(yname){
			start();
			startCount = 1;
		}else{
			alert("请输入名字！");
			$(".yname").focus();
		}
	});
	$(".yname").on("change", function(){
		yname = $(this).val();
	});
	$(".ynum").on("change", function(){
		ynum = $(this).val();
	});
	$(".all").on('click', 'li', function(){
		select();
		var to = $(this).html();
		page = to - 1;
		show_sub(page);
	});
	$(".pre").click(function(){
		if(page == 0){
			alert("已经是第一题了!");
		}else{
			select();
			page--;
			show_sub(page);
		}
	});
	$(".next").click(function(){
		if(page == (len-1)){
			select();
			alert("已经是最后一题了!");
		}else{
			select();
			page++;
			show_sub(page);
		}
	});
	$(".done").click(function(){
		if(hasDone == 1){
			alert("你提交过一次了，不能再提交了");
			return false;
		}
		if(ynum == 0)
		{
			alert("请输入学号！");
			$(".ynum").focus();
			return false;
		}
		if(yname){
			check();
		}else{
			alert("请输入名字！");
			$(".yname").focus();
		}
	});
	$(".reset").click(function(){
		reset();
	});
});
function countT()
{
	if(hasDone == 1){
		$(".countTime strong").html(countTimes);
	}else{
		if(startCount == 0){
			$(".countTime strong").html(countTimes);
		}else{
			if(countTimes == 0){
				alert("时间到！！！！");
				gold();
				clearInterval(timer);
			}else{
				countTimes--;
				$(".countTime strong").html(countTimes);
			}
		}
	}
}
function start(){
	$(".front_page").hide();
	$(".exam_wrap").fadeIn();
	$.ajax({
		url:'/exam/admin/action.php?a=get&c='+type,
		type:'post',
		success:function(msg){
			eval("var ret="+msg);
			ans = ret.ans;
			qus = ret.qus;
			anss = ret.anss;
			for(i=0;i<qus.length;i++){
				data = anss[i].split("#");
				$(".ques:eq("+i+")").html(qus[i]);
				$(".ans:eq("+i+")").find("li:first").html("<input type='radio' name='qus_"+i+"' id='la_"+i+"' value=1 /><label for='la_"+i+"'>A."+data[1]+"</label>");
				$(".ans:eq("+i+")").find("li:eq(1)").html("<input type='radio' name='qus_"+i+"' id='lb_"+i+"' value=2 /><label for='lb_"+i+"'>B."+data[2]+"</label>");
				$(".ans:eq("+i+")").find("li:eq(2)").html("<input type='radio' name='qus_"+i+"' id='lc_"+i+"' value=3 /><label for='lc_"+i+"'>C."+data[3]+"</label>");
				if(data[4]){
					$(".ans:eq("+i+")").find("li:eq(3)").html("<input type='radio' name='qus_"+i+"' id='ld_"+i+"' value=4 /><label for='ld_"+i+"'>D."+data[4]+"</label>");
				}
			}
		}
	});
	show_sub(0);
}
function show_sub(id){
	$(".sub").hide();
	$(".sub:eq("+id+")").show();
	if(is_do){
		$(".all li:eq("+id+")").css("background","url(/exam/img/c_grey.png)");
	}
}
function select(){
	if($(".sub:eq("+page+") :radio:checked").val()){
		user[page] = $(".sub:eq("+page+") :radio:checked").val();
		if(is_do){
			$(".all li:eq("+page+")").css("background","url(/exam/img/c_yellow.png)");
		}
	}else{
		if(is_do){
			$(".all li:eq("+page+")").css("background","url(/exam/img/c_black.png)");
		}
	}
	return true;
}
function check(){
	var num = $(":radio:checked").length;
	if(num < len){
		var n = len - num;
		if(window.confirm('还有'+n+'道题目未回答，确定提交吗？')){
			user[page] = $(".sub:eq("+page+") :radio:checked").val();
			for(i=0;i<len;i++){
				$(".sub:eq("+i+")").find(":radio").attr("disabled","disabled");
			}
			gold();
		}else{
			return false;
		}
	}else{
		if(window.confirm('确定提交吗？')){
			gold();
		}else{
			return false;
		}
	}
}
function reset(){
	window.location.href = '/exam/';
}
function gold(){
	if(hasDone == 1){
		alert("你提交过一次了，不能再提交了");
		return false;
	}
	hasDone = 1;
	is_do=0;
	var j =0;
	$(".tip:first").hide();
	$(".tip:eq(1)").show();
	for(i=0;i<len+1;i++){
		var t = ans[i] - 1;
		var c = user[i] - 1;
		if(ans[i] == user[i] && user[i]){
			j++;
			$(".all li:eq("+i+")").css("background","url(/exam/img/c_green.png)");
			$(".sub:eq("+i+")").find("li:eq("+t+")").css("color","rgb(13, 231, 13)");
		}else{
			$(".all li:eq("+i+")").css("background","url(/exam/img/c_red.png)");
			$(".sub:eq("+i+")").find("li:eq("+t+")").css("color","rgb(13, 231, 13)");
			$(".sub:eq("+i+")").find("li:eq("+c+")").css("color","red");
		}
	}
	var fen = j*perscore;
	$.ajax({
		url:'/exam/admin/action.php?a=gxg&n='+yname+'&f='+fen+'&m='+ynum,
		type:'post',
		success:function(msg){
		}
	});
	if(fen > passscore){
		alert("恭喜你,取得了"+fen+"分的好成绩，已合格");
	}else if(fen == passscore){
		alert("好险啊，差点挂了哦，刚好"+passscore+"分");
	}else{
		alert("亲,你这是肿么了,只有"+fen+"分哦");
	}
}