﻿<?php 
/*powered by GXG.ITC uther*/
include("config.php");
/* get param */
$i = isset($_REQUEST['i']) ? $_REQUEST['i'] : "";/*id*/
$a = isset($_REQUEST['a']) ? $_REQUEST['a'] : "list";/*act*/
$c = isset($_REQUEST['c']) ? $_REQUEST['c'] : "0";/*class*/
$a1 = isset($_REQUEST['a1']) ? $_REQUEST['a1'] : "";/*ans1*/
$a2 = isset($_REQUEST['a2']) ? $_REQUEST['a2'] : "";/*ans2*/
$a3 = isset($_REQUEST['a3']) ? $_REQUEST['a3'] : "";/*ans3*/
$a4 = isset($_REQUEST['a4']) ? $_REQUEST['a4'] : "";/*ans4*/
$k = isset($_REQUEST['k']) ? $_REQUEST['k'] : 0;/*key*/
$q = isset($_REQUEST['q']) ? htmlspecialchars($_REQUEST['q'],ENT_QUOTES) : "";/*问题*/
$n = isset($_REQUEST['n']) ? $_REQUEST['n'] : "";/*名字*/
$f = isset($_REQUEST['f']) ? $_REQUEST['f'] : "";/*分数*/
$m = isset($_REQUEST['m']) ? $_REQUEST['m'] : "";/*学号*/
/* show question */
if($a == "list"){
	if($c){
		$sql = "SELECT * FROM `j_qus` WHERE is_del='0' AND `cla`=$c ORDER BY `id` DESC";
	}else{
		$sql = "SELECT * FROM `j_qus` WHERE is_del='0' ORDER BY `id` DESC";
	}
	$res = mysql_query($sql);
	$html = "<a href='/exam/admin/action.php?a=add'>新增题目</a><br/><table border=1 width=870><th>题号</th><th>分组</th><th>问题</th><th>答案</th><th>回答1</th><th>回答2</th><th>回答3</th><th>回答4</th><th>操作</th></td>";
	for($ii=0;$ii<count($config);$ii++)
	{
		$num[$ii] = 0;
	}
	while($row = mysql_fetch_array($res)){
		$num[$row[cla]]++;
		$html.="<tr><td>".$row[id]."</td><td>".$row[cla]."</td><td>".$row[question]."</td><td>".$row[qkey]."</td><td>".$row[ans1]."</td><td>".$row[ans2]."</td><td>".$row[ans3]."</td><td>".$row[ans4]."</td><td><a href='/exam/admin/action.php?a=edt&i=".$row[id]."'>编辑</a>&nbsp;&nbsp;<a href='/exam/admin/action.php?a=del&i=".$row[id]."'>删除</a></td></tr>";
	}
	$html.="</table>";
	$info = "";
	for($jj=0;$jj<count($config);$jj++)
	{
		$info.= "-".$config[$jj].$num[$jj]."道";
	}
	$info.= $html;
	echo $info;
}
/* insert into data to db */
elseif($a == "add"){
	$html = "<form action='/exam/admin/action.php?a=ins' method='post'><table border=1>";
	$html.="<tr><td>类型:</td><td><select name='c'>";
	for($ii=0;$ii<count($config);$ii++){
		$html.= "<option value='".$ii."'>".$config[$ii]."</option>";
	}
	$html.="</select></td></tr>";
	$html.="<tr><td>问题:</td><td><input type='text' name='q' /></td></tr>";
	$html.="<tr><td>答案:</td><td><input type='text' name='k' /></td></tr>";
	$html.="<tr><td>回答1:</td><td><input type='text' name='a1'/></td></tr>";
	$html.="<tr><td>回答2:</td><td><input type='text' name='a2'/></td></tr>";
	$html.="<tr><td>回答3:</td><td><input type='text' name='a3'/></td></tr>";
	$html.="<tr><td>回答4:</td><td><input type='text' name='a4'/></td></tr>";
	$html.="<tr cols=2><input type='submit' value='提交' /></tr></table></form>";
	echo $html;
}elseif($a == "edt"){
	$sql = "SELECT * FROM `j_qus` WHERE `id`=$i";
	$res = mysql_query($sql);
	$res = mysql_fetch_array($res);
	$html = "<form action='/exam/admin/action.php?a=upd&i=".$i."' method='post'><table border=1>";
	
	$html.="<tr><td>类型:</td><td><select name='c'>";
	for($ii=0;$ii<count($config);$ii++)
	{
		if($ii == $res[cla])
		{
			$html.="<option value='".$ii."' selected>".$config[$ii]."</option>";
		}else
		{
			$html.="<option value='".$ii."'>".$config[$ii]."</option>";
		}
	}
	$html.="</select></td></tr>";
	$html.="<tr><td>问题:</td><td><input type='text' name='q' value='".$res[question]."' /></td></tr>";
	$html.="<tr><td>答案:</td><td><input type='text' name='k' value='".$res[qkey]."'/></td></tr>";
	$html.="<tr><td>回答1:</td><td><input type='text' name='a1' value='".$res[ans1]."'/></td></tr>";
	$html.="<tr><td>回答2:</td><td><input type='text' name='a2' value='".$res[ans2]."'/></td></tr>";
	$html.="<tr><td>回答3:</td><td><input type='text' name='a3' value='".$res[ans3]."'/></td></tr>";
	$html.="<tr><td>回答4:</td><td><input type='text' name='a4' value='".$res[ans4]."'/></td></tr>";
	$html.="<tr cols=2><input type='submit' value='提交' /></tr></table></form>";
	echo $html;
}elseif($a == "ins"){
	if($q){
		$c = $c ? $c : '1';
		$sql = "INSERT INTO `j_qus`(`question`,`cla`,`qkey`,`addtime`,`ans1`,`ans2`,`ans3`,`ans4`) VALUES('".$q."','".$c."',$k,".time().",'".$a1."','".$a2."','".$a3."','".$a4."')";
		$res = mysql_query($sql);
	}
	header("location:/exam/admin/action.php");
}
/* update the data in db */
elseif($a == "upd"){
	$sql = "UPDATE `j_qus` SET `question`='".$q."',`cla`='".$c."',`qkey`=$k,`ans1`='".$a1."',`ans2`='".$a2."',`ans3`='".$a3."',`ans4`='".$a4."' WHERE `id`=$i";
	mysql_query($sql);
	header("location:/exam/admin/action.php");
}
/* to add a del sign in question  */
elseif($a == "del"){
	if($i){
		$sql = "UPDATE `j_qus` SET `is_del`='1' WHERE `id`=$i";
		mysql_query($sql);
	}
	header("location:/exam/admin/action.php");
}
elseif($a == "get"){
	$sql = "SELECT * FROM `j_qus` WHERE `is_del`=0 ORDER BY RAND() LIMIT 0,".$cfg['qus_num'];
	$res = mysql_query($sql);
	$i=0;
	while($row = mysql_fetch_array($res)){
		$i++;
		$arr[ans][] = $row[qkey];
		$arr[qus][] = $i.".".htmlspecialchars_decode($row[question]);
		$arr[anss][] = "#".$row[ans1]."#".$row[ans2]."#".$row[ans3]."#".$row[ans4];
	}
	echo json_encode($arr);exit;
}elseif($a == 'gxg')
{
	if($n){
		$f = $f ? $f : '0';
		$sql = "INSERT INTO `j_exam`(`gname`,`gscore`,`gnum`,`added`) VALUES('".$n."','".$f."','".$m."','".date('Y-m-d H:i:s')."')";
		$res = mysql_query($sql);
	}
	header("location:/exam/admin/action.php");
}elseif($a == 'sc')
{
	$sql = "SELECT * FROM `j_exam`";
	$res = mysql_query($sql);
	while($r = mysql_fetch_row($res))
	{
		echo $r[0]." ".$r[1]." ".$r[2]." ".$r[3]."<br>";
	}
}elseif($a == 'getcfg')
{
	$arr['0'] = $cfg['qus_num'];
	$arr['1'] = $config;
	$arr['2'] = $cfg['passscore'];
	$arr['3'] = $cfg['perscore'];
	$arr['4'] = $cfg['examtime'];
	echo json_encode($arr);exit;
}
?> 