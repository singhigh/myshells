﻿<?php 
/*powered by GXG.ITC uther*/
$db['db_name'] = '1111';
$db['db_user'] = 'root';
$db['db_pwd'] = '';
$db['db_host'] = '';

$set['err_report'] = "E_ALL & ~E_NOTICE";

header("content-type:text/html;charset=utf-8");
ini_set("error_reporting",$set['err_report']);

set_time_limit(0);
$con = mysql_connect($db['db_host'],$db['db_user'],$db['db_pwd']);
mysql_select_db($db['db_name'],$con);
mysql_query("set names 'utf8'");
/*分类设置可自行添加，默认类最好不添加也不用，但不要删除*/
$config['0'] = "默认类";
$config['1'] = "售后类";
/*题目的题数*/
$cfg['qus_num'] = "20";
/*及格分*/
$cfg['passscore'] = "60";
/*每题得分*/
$cfg['perscore'] = "5";
/*考试时间，以秒计*/
$cfg['examtime'] = "1800";


?> 