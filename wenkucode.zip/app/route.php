<?php
use think\Route;

return [
    '__pattern__' => [
        'name' => '\w+',
    ],

];
