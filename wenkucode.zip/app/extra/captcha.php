<?php
        
return [
  
        // 验证码字符集合
        'codeSet'  => '2345678901',
        // 验证码字体大小(px)
        'fontSize' => 22,
        // 是否画混淆曲线
        'useCurve' => true,
        // 验证码位数
        'length'   => 4,
        // 验证成功后是否重置
        'reset'    => true
    
        				
];