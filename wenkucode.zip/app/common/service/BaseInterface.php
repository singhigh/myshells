<?php
// +----------------------------------------------------------------------
// | Author: Zaker <49007623@qq.com>
// +----------------------------------------------------------------------

namespace app\common\service;

/**
 * 服务接口
 */
interface BaseInterface
{
    
    /**
     * 服务信息
     */
    public function serviceInfo();
    
}
