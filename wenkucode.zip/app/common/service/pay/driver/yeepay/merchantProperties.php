<?php

/*
 * @Description 易宝支付产品通用接口范例 
 * @V3.0
 * @Author rui.xin
 */

$p1_MerId       = "";																										#测试使用
$merchantKey	= "";		#测试使用

?> 