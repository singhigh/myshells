<?php
// +----------------------------------------------------------------------
// | Author: Zaker <49007623@qq.com>
// +----------------------------------------------------------------------

namespace app\common\logic;

use app\common\model\ModelBase;

/**
 * 系统通用逻辑模型
 */
class LogicBase extends ModelBase
{

	
	
	
}
