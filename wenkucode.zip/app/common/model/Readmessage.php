<?php

namespace app\common\model;

/**
 * 模型
 */
class Readmessage extends ModelBase
{

	
}
