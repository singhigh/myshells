<?php
// +----------------------------------------------------------------------
// | Author: Zaker <49007623@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\validate;

use app\common\validate\ValidateBase;

/**
 * Admin基础验证器
 */
class AdminBase extends ValidateBase
{


}
