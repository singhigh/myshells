<?php
// +----------------------------------------------------------------------
// | Author: Zaker <49007623@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\service;

use app\common\service\ServiceBase;

/**
 * Admin基础服务
 */
class AdminServiceBase extends ServiceBase
{

    
}
