<?php
// +----------------------------------------------------------------------
// | Author: Zaker <49007623@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\model;

use app\common\model\ModelBase;

/**
 * Admin基础模型
 */
class AdminBase extends ModelBase
{
    
    
}
