<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:48:"E:\wamp\www\addon\imginput\view\index\index.html";i:1533695058;}*/ ?>
    <link rel="stylesheet" href="<?php echo $static_path; ?>css/webuploader.css" />
    <link rel="stylesheet" href="<?php echo $static_path; ?>css/style.css" />
    
    <div id="wrapper" style="width: 80%;" class="remodal"  role="dialog" aria-labelledby="image_upload" aria-describedby="文件上传">
        
       
        
        <div id="container">
            

            <div id="uploader">
                <div class="queueList">
                    <div id="dndArea" class="placeholder">
                        <div id="filePicker"></div>
                        <p>支持拖动文件上传</p>
                    </div>
                </div>
                <div class="statusBar" style="display:none;">
                    
                    <div class="progress">
                        <span class="text">0%</span>
                        <span class="percentage"></span>
                    </div>
                    
                    <div class="info"></div>
                    <div class="btns">
                        <div id="filePicker2"></div><div class="uploadBtn">开始上传</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script src="<?php echo $static_path; ?>dist/webuploader.min.js"></script>
<script src="<?php echo $static_path; ?>js/upload.js"></script>
    
<script type="text/javascript">

var upload_id = "<?php echo $addons_data['id']; ?>";

var max_number = "<?php echo $addons_data['max_number']; ?>";



var img_upload_url ="<?php echo $addons_data['img_upload_url']; ?>"; 

var upload_param = {
        pick: {
            id: '#filePicker',
            label: '点击选择文件'
        },
        formData: {
            uid: 0
        },
        dnd: '#dndArea',
        paste: '#uploader',
        swf: "WEB_URL"+'/addon/imginput/static/dist/Uploader.swf',
        chunked: false,
        chunkSize: 512 * 1024,
        server: img_upload_url,
        // 禁掉全局的拖拽功能。这样不会出现图片拖进页面的时候，把图片打开。
        disableGlobalDnd: true,
        fileNumLimit: max_number,
        //fileSizeLimit: 200 * 1024 * 1024,    // 200 M
        //fileSingleSizeLimit: 50 * 1024 * 1024,    // 50 M
        // 只允许选择图片文件。
        accept: {
            //title: 'Images',
            //extensions: 'gif,jpg,jpeg,bmp,png',
            //mimeTypes: 'image/jpg,image/jpeg,image/png'
        }
    };
var upload_success = function( file, response) {

  
    var show_img_url = response.headpath;
    var cover_id="<?php echo $addons_data['cover_id']; ?>";
    var upload_show_div="<?php echo $addons_data['upload_show_div']; ?>";
    if(upload_show_div!=0){
    	$( '#'+upload_show_div).html("<img style='max-width:100px; margin-right: 20px;' src='"+show_img_url+"' />");
        $('#'+cover_id).val(response.id);
    }else{
    	var coverarr=$('#'+cover_id).val();
    	if(coverarr==0){
    		 $('#'+cover_id).val(response.id);
    	}else{
    		
    		 $('#'+cover_id).val(coverarr+','+response.id);
    	}
       
    }
    

};
</script>