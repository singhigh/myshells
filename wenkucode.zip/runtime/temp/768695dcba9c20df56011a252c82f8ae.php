<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:37:"./template/simple/PC/doc/doclist.html";i:1533695033;s:37:"./template/simple/PC/Public/base.html";i:1533695033;s:39:"./template/simple/PC/Public/header.html";i:1533695033;s:39:"./template/simple/PC/Public/footer.html";i:1536998160;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

         <title><?php echo getdoccatenamebyid($cid); ?>|<?php echo getgroupcatenamebyid($zoneid); ?>|<?php echo \think\Config::get('WEB_SITE_TITLE'); ?> - Powered by EasySNS!</title>
  
  
  <meta name="keywords" content="<?php echo \think\Config::get('WEB_SITE_KEYWORD'); ?>">
  <meta name="description" content="<?php echo \think\Config::get('WEB_SITE_DESCRIPTION'); ?>">
      
<link rel="shortcut icon" href="__PUBLIC__/images/favicon.ico">

 
<link rel="stylesheet" type="text/css" href="__CSS__/bootstrap.css" />

<link rel="stylesheet" type="text/css" href="__CSS__/common.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/common_extend.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/header_footer.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/iconfont.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/font-awesome/css/font-awesome.css" />
    
 <style>
html,body{ background: #fff;}
.pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {

    margin-right: 5px;
    
    overflow: hidden;
    border-color: #fff;
    background: #fff;
    color:#000;
    text-decoration: none;
    text-align: center;
    font-family: arial!important;
}
.pagination > li > a:hover, .pagination > li > span:hover, .pagination > li > a:focus, .pagination > li > span:focus {
background:#f2f8ff;text-decoration:none;color:#0000cd;border:1px solid #38f
}
.pagination > li > a, .pagination > li > span, .pagination > li > a, .pagination > li > span {
  
 
    margin-right: 5px;
   
    overflow: hidden;
    border: 1px solid #e1e2e3;
    background: #fff;
    text-decoration: none;
    text-align: center;
    font-family: arial!important;
  
}
</style>
  

		<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
		<!--[if lt IE 9]>
		<script type="text/javascript" src="__PUBLIC__/js/html5shiv.min.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/respond.min.js"></script>
		<![endif]-->
</head>
<body >
  

  
<script>
function myBrowser(){
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    var isOpera = userAgent.indexOf("Opera") > -1;
    if (isOpera) {
        return "Opera"
    }; //判断是否Opera浏览器
    if (userAgent.indexOf("Firefox") > -1) {
        return "FF";
    } //判断是否Firefox浏览器
    if (userAgent.indexOf("Chrome") > -1){
  return "Chrome";
 }
    if (userAgent.indexOf("Safari") > -1) {
        return "Safari";
    } //判断是否Safari浏览器
    if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
        return "IE";
    }; //判断是否IE浏览器
}
$(function(){
	
	//以下是调用上面的函数
	
	
});


</script>

<div class="es-panel "   >
<div class="container">
<div class="text-center clearfix center-block">
<div  class="pull-left logo">
<img src="__PUBLIC_IMG__/logo-wk.png" />
</div>
<form action="<?php echo url('search/index'); ?>" class="pull-left " name="ftop" id="topSearchBox" method="get">
<span class="s_ipt_wr pull-left">
<input id="kw" name="keyword" class="s_ipt" maxlength="256" tabindex="1" value="<?php echo (isset($keyword) && ($keyword !== '')?$keyword:''); ?>" data-default="" autocomplete="off" placeholder="">

</span>
<span class="s_btn_wr">
<input type="submit" id="sb" value="搜索文档" class="s_btn s_btn_wr_click">
</span>

<div class="text-left es-margin-t-10" >
<label class="radio-inline">

  <input type="radio" checked name="ext"  value="0"> 全部
</label>
<label class="radio-inline">
  <input type="radio" name="ext"  value="doc"> DOC
</label>
<label class="radio-inline">
  <input type="radio" name="ext"  value="ppt"> PPT
</label>
<label class="radio-inline">
  <input type="radio" name="ext" value="txt"> TXT
</label>
<label class="radio-inline">
  <input type="radio"  name="ext"  value="pdf"> PDF
</label>
<label class="radio-inline">
  <input type="radio"  name="ext" value="xls"> XLS
</label>
</div>

</form>

</div>


</div>
</div>


<div class="nav-wrap es-margin-b-20">
<div class="ui-nav">
<div class="container" >
<div class="inner clearfix">
<ul class="clearfix main-nav leftnav" alog-group="general.nav">

<?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo['pid'] == '1'): ?>
<li id="<?php echo $vo['alias']; ?>" <?php if(true == getnavactive(getnavlink($vo['link'],$vo['sid']))): ?>class="current"<?php endif; ?>><a href="<?php echo getnavlink($vo['link'],$vo['sid']); ?>" target="<?php echo $vo['target']; ?>" title="<?php echo $vo['alias']; ?>"><?php echo $vo['name']; ?></a></li>
      <?php endif; endforeach; endif; else: echo "" ;endif; ?>


</ul>
<ul class="main-nav side-nav clearfix">
<?php if(session('member_info') != null): ?>
<li class="last">
<a href="<?php echo url('user/index'); ?>" id="nav-myWenku" class="logSend" >
<i class="userbg" ></i> 个人中心</a>
<?php if(($nowuid > 0) AND ($messcount > 0)): ?>
<a href="<?php echo url('user/mess'); ?>"  class="logSend" style="width:50px;">
<i class="iconfont icon-remind" ></i> <span class="badge " style="background-color: #d9534f;position:absolute;top:0px;right:5px;padding: 3px 5px;"><?php echo $messcount; ?></span></a>
<?php endif; ?>

</li>
<li style="display:none;margin-left:20px;color:#fff;">浏览/下载&nbsp;&nbsp;<?php echo $alldocviewcount; ?>/<?php echo $alldocdowncount; ?></li>


<?php endif; ?>

</ul>
</div>
</div>
</div>
</div>


  
<div class="container">
<div class="leftcon">
  <div class="bread">
  <ul>
  <li><a href="<?php echo url('index/index'); ?>"><?php echo \think\Config::get('WEB_SITE_TITLE'); ?></a></li>
  <i class="fa  fa-angle-right"></i>
      <li><a href="<?php echo url('doc/doccatelist',array('id'=>$zoneid)); ?>"><?php echo getgroupcatenamebyid($zoneid); ?></a></li>
      <i class="fa  fa-angle-right"></i>
        <li class="current"><?php echo getdoccatenamebyid($cid); ?></li>
  </ul>
  </div>
    <?php if(!empty($cidinfo['describe'])): ?>
  <div class="cpmsg-wrap">

  <?php echo $cidinfo['describe']; ?>

  </div>
    <?php endif; ?>
  <div class="main">

<div class="mod catalog">
<b class="top"><b class="tl"></b><b class="tr"></b></b>
<div class="inner">

<div class="hd"><h2><?php echo getgroupcatenamebyid($zoneid); ?></h2></div>
<div class="bd">
<table cellpadding="0" cellspacing="0" width="100%" id="classList">
<tbody>

<?php if(is_array($doccatelist) || $doccatelist instanceof \think\Collection || $doccatelist instanceof \think\Paginator): $i = 0; $__LIST__ = $doccatelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>


<tr>
<?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$subvo): $mod = ($i % 2 );++$i;?>
<td >
<a href="<?php echo url('doc/doclist',array('zoneid'=>$subvo['pid'],'cid'=>$subvo['id'])); ?>"><?php echo $subvo['name']; ?></a>&nbsp;
</td>
<?php endforeach; endif; else: echo "" ;endif; ?>
</tr>

<?php endforeach; endif; else: echo "" ;endif; ?>
<tr>
</tr>
</tbody>
</table>
</div>
</div>
<b class="bottom"><b class="bl"></b><b class="br"></b></b>
</div>

<div class="mod dataList">

<div id="tabContent" class="tabContent">
<table cellpadding="0" cellspacing="0" class="list" width="100%" id="docList">
<tbody>
<tr>
<th width="40">格式</th><th width="394">文档名称</th><th width="100">上传者</th>
<th width="70">
<?php if($sorttype == 1): ?>
下载量<span title="按下载量排序" class="icon sort"></span>
<?php else: ?>
<a title="按下载量排序" href="<?php echo url('doc/doclist',array('zoneid'=>$zoneid,'cid'=>$cid,'sorttype'=>1)); ?>">下载量</a>
<?php endif; ?>

</th>
<th width="70">
<?php if($sorttype == 0): ?>
上传时间<span title="按上传时间排序" class="icon sort"></span>
<?php else: ?>
<a title="按上传时间排序" href="<?php echo url('doc/doclist',array('zoneid'=>$zoneid,'cid'=>$cid,'sorttype'=>0)); ?>">上传时间</a>
<?php endif; ?>

</th>
</tr>
<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if(($vo['create_time'] > $update_time) AND ($update_time > 0)): ?>
<tr class="hasb">
<?php else: ?>
<tr>
<?php endif; ?>
<td class="i">
<span title="doc" class="ic ic-<?php echo strtolower($vo['ext']); ?>"></span>
</td>
<td class="relative">
<?php if(($vo['create_time'] > $update_time) AND ($update_time > 0)): ?><i class="iconfont icon-yuandianxiao-copy-copy"></i><?php endif; ?>

<a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a>
<span class="history-page"><?php echo $vo['pageid']; ?>页</span>

</td>
<td class="un">
<div>
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" class="Author logSend" target="_blank"><?php echo $vo['nickname']; ?></a>
</div>
</td>
<td><span><?php echo $vo['down']; ?>次</span></td>
<td><span><?php echo friendlyDate($vo['create_time']); ?></span></td>
</tr>
<?php endforeach; endif; else: echo "" ;endif; ?>


</tbody>
</table>
</div>
</div>
<div class="pages">
<?php echo $list->render(); ?>
</div>



</div>
  
</div>
<div class="rightcon">
<div class="aside" style="padding:0px 5px;">


<div id="upload-box" class="mod mb10 skin-upload">
<div class="inner">
<div class="cd c-align">
<div class="mb20"></div>
<p class="share-button">
<a class="btn btn-warning btn-block"  href="<?php echo url('doc/docupload'); ?>" style="font-size:20px;">
<i class="iconfont icon-shangchuan2" style="font-size:26px;"></i> 上传我的文档</a>
</p>
</div>
</div>
</div>
<!--阅读排行top10-->
<div id="rank-read" class="mod mb10 skin-default">
    <div class="inner">
        <div class="hd"><b class="f-black">下载排行榜</b></div>
        <div class="cd c-align">
            <ul class="rank-tab">
                <li class="tab-1 tab-on current" data-id="downrank1">本日</li>
                <li class="tab-2 disabled" data-id="downrank2">本周</li>
                <li class="tab-3 disabled" data-id="downrank3">本月</li>
            </ul>
            <div class="clearfix"></div>
            <div class="rank-content">
            <div class="rank current" style="" id="downrank1">
                <ul>
<?php if(is_array($docdownrankday) || $docdownrankday instanceof \think\Collection || $docdownrankday instanceof \think\Paginator): $i = 0; $__LIST__ = $docdownrankday;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank" ><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="rank disabled" style=""  id="downrank2">
                <ul>

<?php if(is_array($docdownrankzhou) || $docdownrankzhou instanceof \think\Collection || $docdownrankzhou instanceof \think\Paginator): $i = 0; $__LIST__ = $docdownrankzhou;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank" ><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="rank disabled" style=""  id="downrank3">
                <ul>

<?php if(is_array($docdownrankmouth) || $docdownrankmouth instanceof \think\Collection || $docdownrankmouth instanceof \think\Paginator): $i = 0; $__LIST__ = $docdownrankmouth;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank"><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            </div>
        </div>
    </div>
</div>
<!--文辑收藏排行榜-->
<div id="rank-album" class="mod mb10 skin-default">
    <div class="inner">
        <div class="hd"><b class="f-black">热门排行榜</b></div>
        <div class="cd c-align">
            <ul class="rank-tab">
                <li class="tab-1 tab-on current" data-id="viewrank1">本日</li>
                <li class="tab-2 disabled" data-id="viewrank2">本周</li>
                <li class="tab-3 disabled" data-id="viewrank3">本月</li>
            </ul>
            <div class="clearfix"></div>
            <div class="rank-content">
            <div class="rank current" style=""  id="viewrank1">
                <ul>

<?php if(is_array($docviewnrankday) || $docviewnrankday instanceof \think\Collection || $docviewnrankday instanceof \think\Paginator): $i = 0; $__LIST__ = $docviewnrankday;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank"><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="rank disabled" style=""  id="viewrank2">
                <ul>

<?php if(is_array($docviewrankzhou) || $docviewrankzhou instanceof \think\Collection || $docviewrankzhou instanceof \think\Paginator): $i = 0; $__LIST__ = $docviewrankzhou;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank"><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            <div class="rank disabled" style=""  id="viewrank3">
                <ul>

<?php if(is_array($docviewrankmouth) || $docviewrankmouth instanceof \think\Collection || $docviewrankmouth instanceof \think\Paginator): $i = 0; $__LIST__ = $docviewrankmouth;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li  class="ellipsis"><a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" title="<?php echo $vo['title']; ?>" target="_blank"><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
            </div>
        </div>
    </div>
</div>





</div>
</div>
</div>

  

  

  
<div id="ft"><div class="footer"><p>Copyright © 2017 imzaker.com 版权所有  <?php echo \think\Config::get('web_site_icp'); ?></p><?php echo html_entity_decode(\think\Config::get('web_site_footer')); ?></div></div>
<script type="text/javascript" src="__PUBLIC__/js/layer/layer.js"></script>
<script type="text/javascript" src="__PUBLIC__/js/common.js"></script>

<!--页面JS脚本-->

</body>
</html>