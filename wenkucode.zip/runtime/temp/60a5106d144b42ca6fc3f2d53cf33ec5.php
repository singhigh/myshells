<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:44:"E:\wamp\www/app/admin\view\message_list.html";i:1533695055;s:36:"E:\wamp\www/app/admin\view\base.html";i:1533695055;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>资源邦后台管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="__ADMIN__/layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="__PUBLIC__/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="__ADMIN__/css/frame.css" media="all" />
	<script type="text/javascript" src="__ADMIN__/layui/layui.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
    
	
	
</head>
<body class="childrenBody" style="padding-bottom:40px;">

<blockquote class="layui-elem-quote news_search">

        <div class="layui-inline">
		
<ob_link><a class="layui-btn layui-btn-normal Add_btn" data-title="添加消息" data-url="<?php echo url('messageAdd'); ?>"><i class="fa fa-plus"></i> 新 增</a></ob_link>
			
</div>
<div class="layui-inline">
			<ob_link><a class="layui-btn layui-btn-danger batchDel" data-url="<?php echo url('messageAlldel'); ?>">批量删除</a></ob_link>
		</div>
</blockquote>
	<div class="layui-form users_list">
	  	<table class="layui-table">
				<thead>
                    <tr>
                      <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
					<th width="5%" style="text-align:center"><input type="checkbox" name="" lay-skin="primary" lay-filter="allChoose" id="allChoose"></th>
					 <?php endif; ?>
                        <th>时间</th>
                        <th>发送者</th>
                         <th>发送对象</th>
                        <th>类型</th>
                        <th>内容</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                       <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
                  <tbody class="users_content">
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                    <tr>
                        <td width="5%" style="text-align:center"><input type="checkbox" name="checked" lay-skin="primary" lay-filter="choose" value="<?php echo $vo['id']; ?>"></td>
                        <td><?php echo friendlyDate($vo['update_time']); ?></td>
                        <td><?php echo $vo['uid']==0 ? '系统' : getusernamebyid($vo['uid']); ?></td>
                         <td><?php echo getusernamebyid($vo['touid']); ?></td>
                          <td><?php echo $vo['type']==1 ? '系统消息' : '帖子动态'; ?></td>
                          <td><?php echo $vo['content']; ?></td>
                        <td>
                               <ob_link><a data-title="编辑消息"  data-url="<?php echo url('messageEdit',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-mini users_edit"><i class="fa fa-edit"></i>编辑</a></ob_link>
                     
                      <ob_link><a class="layui-btn layui-btn-danger layui-btn-mini users_del" href="javascript:;"  data-url="<?php echo url('messageDel', array('id' => $vo['id'])); ?>"><i class="fa fa-trash-o"></i> 删 除</a></ob_link>
                 
                      </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                      <?php else: ?>
       <tbody class="users_content">
       <tr class="odd"><td colspan="8" class="text-center" valign="top"><?php echo config('empty_list_describe'); ?></td></tr>
       </tbody>
      <?php endif; ?>
                </table>
	</div>
			

  
<div class="btable-paged" >
<div class="layui-main">
	<?php echo $list->render(); ?>
</div>
</div>
 


	
	
	<script type="text/javascript" src="__ADMIN__/js/main.js"></script>
		
	
<!--页面JS脚本-->

</body>
</html>