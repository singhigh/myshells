<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:42:"E:\wamp\www/app/admin\view\index_home.html";i:1536998469;s:36:"E:\wamp\www/app/admin\view\base.html";i:1536998510;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>吾爱源码后台管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="__ADMIN__/layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="__PUBLIC__/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="__ADMIN__/css/frame.css" media="all" />
	<script type="text/javascript" src="__ADMIN__/layui/layui.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
    
	
	
</head>
<body class="childrenBody" style="padding-bottom:40px;">

<style>
.tpt-index table {
    margin-bottom: 10px;
}
.tpt-index tr {
    font-size: 13px;
    line-height: 38px;
    border-bottom: 1px solid rgb(234, 234, 234);
}
.tpt-index td{padding-left:10px;}
</style>
	<div class="tpt-index fly-panel fly-panel-user">
<blockquote style="padding: 10px;border-left: 5px solid #009688;" class="layui-elem-quote">欢迎使用吾爱源码文章管理系统，<span style="color:#FF5722;">已授权</span></blockquote>
<table width="100%" >
<tr>
<td width="50%">程序正式上线运营请记得保留我们版权；</td>
<td>确认服务器或空间开启了伪静态；</td>
</tr>
<tr>
<td>如需去掉版权请联系我们QQ993424780；</td>
<td>如果没有伪静态，请关闭配置文件中的路由功能；</td>
</tr>
<tr>
<td>尽管本程序在发布前已经经过了若干严格测试；</td>
<td>程序安装好后一定记得修改默认密码；</td>
</tr>
</table>

 <blockquote style="padding: 10px;border-left: 5px solid #009688;" class="layui-elem-quote">产品信息：</blockquote>       
<table width="100%"  >
        <tr><td>产品名称</td><td><?php echo $data['product_name']; ?></td></tr>
        
        <tr><td width="110px">程序版本</td><td><?php echo $data['ob_version']; ?> <a href="javascript:;" data-url="<?php echo url('index/deal_sql'); ?>" id="update" style="color:#FF5722;"  target="_blank">升级最新版本</a>【最新版本<?php echo $data['do']['ver'][2]; ?><a href="http://www.wazyb.com" style="color:#F7B824;"  target="_blank">去官网</a>】</td></tr>
        
        <tr><td>开发者</td><td><?php echo $data['author']; ?></td></tr>
        <tr><td>官网地址</td><td><?php echo $data['website']; ?></td></tr>
        <tr><td>官方讨论群</td><td><?php echo $data['qun']; ?></td></tr>
        <tr><td>帮助文档</td><td><?php echo $data['document']; ?></td></tr>
<tr><td>特别提醒您</td><td>本程序均可免费下载使用，但严禁删除、隐藏或更改版权信息，且导致的一切损失由使用者自行承担。</td></tr>
</table>
<blockquote style="padding: 10px;border-left: 5px solid #009688;" class="layui-elem-quote">系统信息：</blockquote>
<table width="100%">

     
        <tr><td width="110px">ThinkPHP版本</td><td><?php echo $data['think_version']; ?></td></tr>
        <tr><td>操作系统</td><td><?php echo $data['os']; ?></td></tr>
        <tr><td>运行环境</td><td><?php echo $data['software']; ?></td></tr>
        <tr><td>MySql版本</td><td><?php echo $data['mysql_version']; ?></td></tr>
        
        <tr><td>PHP版本</td><td><?php echo $data['php_version']; ?></td></tr>
        <tr><td>上传限制</td><td><?php echo $data['upload_max']; ?></td></tr>
        </table>
</div>
    
  


	
	
	<script type="text/javascript" src="__ADMIN__/js/main.js"></script>
		
	
<!--页面JS脚本-->

    <script>
    layui.use(['layer','jquery'],function(){
    	  var jq = layui.jquery;
    	  
    	  
    	  jq('#update').click(function(){
    		  
    		  var url=jq(this).data('url');
    		    jq.getJSON(url,function(data){
    		    	  loading = layer.load(2, {
    		    	      shade: [0.2,'#000']
    		    	    });
    		    	
    		      if(data.code == 200){
    		        layer.close(loading);
    		        layer.msg(data.msg, {icon: 1, time: 1000}, function(){
    		          
    		        });
    		      }else{
    		        layer.close(loading);
    		        layer.msg(data.msg, {icon: 2, anim: 6, time: 1000});
    		      }
    		    });
    		    return false;
    	});

    	})
    </script>
        
</body>
</html>