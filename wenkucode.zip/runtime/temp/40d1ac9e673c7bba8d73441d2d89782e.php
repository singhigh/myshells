<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:48:"E:\wamp\www/app/admin\view\index_adminindex.html";i:1533695055;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>资源邦后台管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Access-Control-Allow-Origin" content="*">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="icon" href="__PUBLIC__/images/favicon.ico">
	<link rel="stylesheet" href="__ADMIN__/layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="__ADMIN__/css/main.css" media="all" />
	<link rel="stylesheet" href="__PUBLIC__/font-awesome/css/font-awesome.min.css">
	<script type="text/javascript" src="__ADMIN__/layui/layui.js"></script>
	  <!--[if lt IE 9]>
    <script src="__PUBLIC__/js/html5shiv.min.js"></script>
    <script src="__PUBLIC__/js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="main_body">
	<div class="layui-layout layui-layout-admin ">
		<!-- 顶部 -->
		<div class="layui-header header">
			<div class="layui-main">
				<a href="#" class="logo">资源邦后台管理</a>
				<!-- 显示/隐藏菜单 -->
				<a href="javascript:;" class="fa fa-bars hideMenu"></a>
				<!-- 搜索 -->
				

			    <!-- 顶部右侧菜单 -->
			    <ul class="layui-nav top_menu">
			    	<li class="layui-nav-item " id="showNotice" pc>
						<a class="update_cache" href="javascript:void(0)"  data-url="<?php echo url('login/clearCache'); ?>"><i class="fa fa-eraser"></i><cite>清理缓存</cite></a>
					</li>
					<li class="layui-nav-item " id="showNotice" pc>
						<a class="update_cache" href="javascript:void(0)"  data-url="<?php echo url('Ybcommand/changepageid'); ?>"><i class="fa fa-eraser"></i><cite>更新页码</cite></a>
					</li>
			    	<li class="layui-nav-item">
			    		<a href="<?php echo $root; ?>" target="_blank" >
			    		<i class="fa fa-home"></i><cite>浏览网站</cite></a>
			    	</li>
			    	<li class="layui-nav-item" mobile>
			    		<a href="javascript:void(0)" class="signOut" data-url="<?php echo url('login/logout'); ?>"><i class="fa fa-power-off"></i> 退出</a>
			    	</li>
					<li class="layui-nav-item lockcms" pc>
						<a href="javascript:;"><i class="fa fa-braille"></i><cite>锁屏</cite></a>
					</li>
								<!--锁屏模板 start-->
			<script type="text/template" id="lock-temp">
				<div class="admin-header-lock" id="lock-box">
					<div class="admin-header-lock-img">
						<img src="<?php echo $root; ?><?php echo $member_info['userhead']; ?>"/>
					</div>
					<div class="admin-header-lock-name" id="lockUserName"><?php echo $member_info['username']; ?></div>
					<input type="text" class="admin-header-lock-input  layui-input" value="输入密码解锁.." name="lockPwd" id="lockPwd" />
					<button class="layui-btn" id="unlock">解锁</button>
				</div>
			</script>
			<!--锁屏模板 end -->
					<li class="layui-nav-item" pc>
						<a href="javascript:;">
							<img src="<?php echo $root; ?><?php echo $member_info['userhead']; ?>" class="layui-circle" width="35" height="35">
							<cite><?php echo $member_info['nickname']; ?></cite>
						</a>
						<dl class="layui-nav-child">
							
							<dd><a id="changemima" href="javascript:;"  data-url="<?php echo url('user/changePass'); ?>"><i class="fa fa-lock" ></i><cite>修改密码</cite></a></dd>
							
							<dd><a  href="javascript:void(0)" class="signOut" data-url="<?php echo url('login/logout'); ?>"><i class="fa fa-power-off"></i><cite>退出</cite></a></dd>
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<!-- 左侧导航 -->
		<div class="layui-side layui-bg-black">
			
			<div class="navBar layui-side-scroll"></div>
		</div>
		<!-- 右侧内容 -->
		<div class="layui-body layui-form">
			<div class="layui-tab marg0" lay-filter="bodyTab" id="top_tabs_box">
				<ul class="layui-tab-title top_tab" id="top_tabs">
					<li class="layui-this" lay-id=""><i class="fa fa-dashboard"></i> <cite>后台首页</cite></li>
				</ul>
				<ul class="layui-nav closeBox" style="padding:0px 20px 0px 0px">
				  <li class="layui-nav-item">
				    <a href="javascript:;"><i class="fa fa-bullseye"></i> 页面操作</a>
				    <dl class="layui-nav-child">
				      <dd><a href="javascript:;" class="closePageOther"><i class="fa fa-ban"></i> 关闭其他</a></dd>
				      <dd><a href="javascript:;" class="closePageAll"><i class="fa fa-times-circle-o"></i> 关闭全部</a></dd>
				    </dl>
				  </li>
				</ul>
				<div class="layui-tab-content clildFrame">
					<div class="layui-tab-item layui-show">
					<iframe src="<?php echo url('index/home'); ?>"></iframe>
						
					</div>
				</div>
			</div>
		</div>
		<!-- 底部 -->
		
	</div>
	
	<!-- 移动导航 -->
	<div class="site-tree-mobile layui-hide"><i class="layui-icon">&#xe602;</i></div>
	<div class="site-mobile-shade"></div>

				<script>
				var navs = '<?php echo $menu_view; ?>';
			
				
			
		
			var lockurl="<?php echo url('login/locker'); ?>";
			</script>
	<script type="text/javascript" src="__ADMIN__/js/leftNav.js"></script>
	<script type="text/javascript" src="__ADMIN__/js/index.js"></script>

</body>
</html>