<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:43:"E:\wamp\www/app/admin\view\doccate_add.html";i:1533695055;s:36:"E:\wamp\www/app/admin\view\base.html";i:1533695055;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>资源邦后台管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="__ADMIN__/layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="__PUBLIC__/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="__ADMIN__/css/frame.css" media="all" />
	<script type="text/javascript" src="__ADMIN__/layui/layui.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
    
	
	
</head>
<body class="childrenBody" style="padding-bottom:40px;">


    <!--tab标签-->
    <div class="layui-tab-brief">
    
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <form class="layui-form form-container" data-url="<?php echo url('doccateAdd'); ?>"  localtion-url="<?php echo url('doccateList'); ?>" >
                    <div class="layui-form-item">
                        <label class="layui-form-label">所属频道</label>
                        <div class="layui-input-inline">
                              <select name="pid" class="layui-input">
                                                <?php if(is_array($groupcate_list) || $groupcate_list instanceof \think\Collection || $groupcate_list instanceof \think\Paginator): $i = 0; $__LIST__ = $groupcate_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                    <option value="<?php echo $vo['id']; ?>"  ><?php echo $vo['name']; ?></option>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                             </select>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">分类名称</label>
                        <div class="layui-input-inline">
                            <input type="text" name="name" value="" required  lay-verify="required" placeholder="请输入分类名称" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">分类简介</label>
                        <div class="layui-input-block">
                         <textarea name="describe" placeholder="请输入分类简介" class="layui-textarea"></textarea>
                       
                        </div>
                    </div>
                    
                                        <div class="layui-form-item">
                        <label class="layui-form-label">排序</label>
                        <div class="layui-input-inline">
                            <input type="text" name="sort" value="0" required  lay-verify="required" class="layui-input">
                        </div>
                    </div>
                
                 
                    <div class="btable-paged" >
				<div class="layui-main">
                    <div class="formbtngroup">
<button class="layui-btn layui-btn-small" lay-submit="" lay-filter="formadd">添加</button>
<a href="javascript:;"  class="layui-btn layui-btn-primary layui-btn-small closebtn">返回</a>
</div>
</div>
        </div>
                </form>
            </div>
        </div>
    </div>


  


	
	
	<script type="text/javascript" src="__ADMIN__/js/main.js"></script>
		
	
<!--页面JS脚本-->

</body>
</html>