<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:42:"E:\wamp\www/app/admin\view\docxs_list.html";i:1533695055;s:36:"E:\wamp\www/app/admin\view\base.html";i:1536998510;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>吾爱源码后台管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="__ADMIN__/layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="__PUBLIC__/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="__ADMIN__/css/frame.css" media="all" />
	<script type="text/javascript" src="__ADMIN__/layui/layui.js"></script>
	<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
    
	
	
</head>
<body class="childrenBody" style="padding-bottom:40px;">

<blockquote class="layui-elem-quote news_search">
		<div class="layui-inline">
		
		<form id="searchform">
		    
		    <div class="layui-input-inline search-form">
		  <select name="status" class="layui-input">
                                           
                                                    <option value="0"  <?php if((input('status') != 2) AND (input('status') != 1) AND (input('status') != 3)): ?>selected<?php endif; ?>>全部</option>
                                                    <option value="3"  <?php if(input('status') == 3): ?>selected<?php endif; ?>>待审核</option>
                                                    <option value="1"  <?php if(input('status') == 1): ?>selected<?php endif; ?>>审核通过</option>
                                                     <option value="2"  <?php if(input('status') == 2): ?>selected<?php endif; ?>>结束</option>
                                             
              </select>
		    </div>
		    <a class="layui-btn search_btn"  id="search" data-url="<?php echo url('docxslist'); ?>">查询</a>
		    </form>
		</div>

<div class="layui-inline">
			<ob_link><a class="layui-btn layui-btn-danger batchDel" data-url="<?php echo url('docxsAlldel'); ?>">批量删除</a></ob_link>
			<ob_link><a class="layui-btn layui-btn-danger batchSh"  tiperror="请选择需要审核的数据" tipconfirm="确定审核选中的信息？"  data-url="<?php echo url('docxsAllSh'); ?>">批量审核</a></ob_link>
		</div>
</blockquote>
	<div class="layui-form users_list">
	  	<table class="layui-table">
				<thead>
                    <tr>
                      <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
					<th width="5%" style="text-align:center"><input type="checkbox" name="" lay-skin="primary" lay-filter="allChoose" id="allChoose"></th>
					 <?php endif; ?>
                        <th><a href="">标题</a></th>
                        <th>需求</th>
                        <th>所属分类</th>
                        <th>所属频道</th>
                         <th>悬赏积分</th>
                         <th>剩余天数</th>
                       <th>发布者</th>
                        <th>状态</th>
                        <th>时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                       <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
                  <tbody class="users_content">
                    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                    <tr>
                        <td width="5%" style="text-align:center"><input type="checkbox" name="checked" lay-skin="primary" lay-filter="choose" value="<?php echo $vo['id']; ?>"></td>
                       
                        <td><?php echo $vo['title']; ?></td>
                        <td><?php echo $vo['description']; ?></td>
                        <td><?php echo $vo['tidname']; ?></td>
                        <td><?php echo $vo['gidname']; ?></td>
                         <td><?php echo $vo['score']; ?></td>
                          <td><?php echo $vo['days']; ?></td>
                         <td><?php echo $vo['username']; ?></td>
                         <td><?php if($vo['status']==2){echo '结束';}else if($vo['status']==1){echo '通过';}else{echo '待审核';} ?></td>
                           <td><?php echo friendlyDate($vo['create_time']); ?></td>
                        <td>
                       <ob_link><a class="layui-btn layui-btn-danger layui-btn-mini cstatus" href="javascript:;"  data-url="<?php echo url('docxsCstatus', array('id' => $vo['id'])); ?>" data-field="status" data-val="<?php echo $vo['status']; ?>"><i class="fa fa-gavel"></i> <?php echo $vo['status']>0 ? '禁用' : '审核'; ?></a></ob_link>
                      <ob_link><a class="layui-btn layui-btn-danger layui-btn-mini users_del" href="javascript:;"  data-url="<?php echo url('docxsDel', array('id' => $vo['id'])); ?>"><i class="fa fa-trash-o"></i> 删 除</a></ob_link>
                 
                      </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                      <?php else: ?>
       <tbody class="users_content">
       <tr class="odd"><td colspan="8" class="text-center" valign="top"><?php echo config('empty_list_describe'); ?></td></tr>
       </tbody>
      <?php endif; ?>
                </table>
	</div>
			

  
<div class="btable-paged" >
<div class="layui-main">
	<?php echo $list->render(); ?>
</div>
</div>
 


	
	
	<script type="text/javascript" src="__ADMIN__/js/main.js"></script>
		
	
<!--页面JS脚本-->

</body>
</html>