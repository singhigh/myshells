<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:37:"./template/simple/PC/index/index.html";i:1533695033;s:37:"./template/simple/PC/Public/base.html";i:1533695033;s:39:"./template/simple/PC/Public/header.html";i:1533695033;s:39:"./template/simple/PC/Public/footer.html";i:1536998160;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

         <title><?php echo \think\Config::get('WEB_SITE_TITLE'); ?> - Powered by EasySNS!</title>
  
  
  <meta name="keywords" content="<?php echo \think\Config::get('WEB_SITE_KEYWORD'); ?>">
  <meta name="description" content="<?php echo \think\Config::get('WEB_SITE_DESCRIPTION'); ?>">
      
<link rel="shortcut icon" href="__PUBLIC__/images/favicon.ico">

 
<link rel="stylesheet" type="text/css" href="__CSS__/bootstrap.css" />

<link rel="stylesheet" type="text/css" href="__CSS__/common.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/common_extend.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/header_footer.css" />
<link rel="stylesheet" type="text/css" href="__CSS__/iconfont.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/font-awesome/css/font-awesome.css" />
    
  <link rel="stylesheet" type="text/css" href="__CSS__/index.css" />

  <link rel="stylesheet" type="text/css" href="__PUBLIC__/js/swiper/swiper-3.4.2.min.css" />

<style>




.container{min-width: 980px;
    max-width: 1200px;
    width:100%;
    
    }
    .ui-nav .container{padding:0px;}
</style>
  

		<script type="text/javascript" src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
		<!--[if lt IE 9]>
		<script type="text/javascript" src="__PUBLIC__/js/html5shiv.min.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/respond.min.js"></script>
		<![endif]-->
</head>
<body >
  
  
<script>
function myBrowser(){
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    var isOpera = userAgent.indexOf("Opera") > -1;
    if (isOpera) {
        return "Opera"
    }; //判断是否Opera浏览器
    if (userAgent.indexOf("Firefox") > -1) {
        return "FF";
    } //判断是否Firefox浏览器
    if (userAgent.indexOf("Chrome") > -1){
  return "Chrome";
 }
    if (userAgent.indexOf("Safari") > -1) {
        return "Safari";
    } //判断是否Safari浏览器
    if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
        return "IE";
    }; //判断是否IE浏览器
}
$(function(){
	
	//以下是调用上面的函数
	
	
});


</script>

<div class="es-panel "   >
<div class="container">
<div class="text-center clearfix center-block">
<div  class="pull-left logo">
<img src="__PUBLIC_IMG__/logo-wk.png" />
</div>
<form action="<?php echo url('search/index'); ?>" class="pull-left " name="ftop" id="topSearchBox" method="get">
<span class="s_ipt_wr pull-left">
<input id="kw" name="keyword" class="s_ipt" maxlength="256" tabindex="1" value="<?php echo (isset($keyword) && ($keyword !== '')?$keyword:''); ?>" data-default="" autocomplete="off" placeholder="">

</span>
<span class="s_btn_wr">
<input type="submit" id="sb" value="搜索文档" class="s_btn s_btn_wr_click">
</span>

<div class="text-left es-margin-t-10" >
<label class="radio-inline">

  <input type="radio" checked name="ext"  value="0"> 全部
</label>
<label class="radio-inline">
  <input type="radio" name="ext"  value="doc"> DOC
</label>
<label class="radio-inline">
  <input type="radio" name="ext"  value="ppt"> PPT
</label>
<label class="radio-inline">
  <input type="radio" name="ext" value="txt"> TXT
</label>
<label class="radio-inline">
  <input type="radio"  name="ext"  value="pdf"> PDF
</label>
<label class="radio-inline">
  <input type="radio"  name="ext" value="xls"> XLS
</label>
</div>

</form>

</div>


</div>
</div>


<div class="nav-wrap es-margin-b-20">
<div class="ui-nav">
<div class="container" >
<div class="inner clearfix">
<ul class="clearfix main-nav leftnav" alog-group="general.nav">

<?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo['pid'] == '1'): ?>
<li id="<?php echo $vo['alias']; ?>" <?php if(true == getnavactive(getnavlink($vo['link'],$vo['sid']))): ?>class="current"<?php endif; ?>><a href="<?php echo getnavlink($vo['link'],$vo['sid']); ?>" target="<?php echo $vo['target']; ?>" title="<?php echo $vo['alias']; ?>"><?php echo $vo['name']; ?></a></li>
      <?php endif; endforeach; endif; else: echo "" ;endif; ?>


</ul>
<ul class="main-nav side-nav clearfix">
<?php if(session('member_info') != null): ?>
<li class="last">
<a href="<?php echo url('user/index'); ?>" id="nav-myWenku" class="logSend" >
<i class="userbg" ></i> 个人中心</a>
<?php if(($nowuid > 0) AND ($messcount > 0)): ?>
<a href="<?php echo url('user/mess'); ?>"  class="logSend" style="width:50px;">
<i class="iconfont icon-remind" ></i> <span class="badge " style="background-color: #d9534f;position:absolute;top:0px;right:5px;padding: 3px 5px;"><?php echo $messcount; ?></span></a>
<?php endif; ?>

</li>
<li style="display:none;margin-left:20px;color:#fff;">浏览/下载&nbsp;&nbsp;<?php echo $alldocviewcount; ?>/<?php echo $alldocdowncount; ?></li>


<?php endif; ?>

</ul>
</div>
</div>
</div>
</div>


  
  <div class="container">
 <div class="onepanel row">
 <div class="cate" id="wk-all-cate">
 <?php if(is_array($catelist) || $catelist instanceof \think\Collection || $catelist instanceof \think\Paginator): $i = 0; $__LIST__ = $catelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$catevo): $mod = ($i % 2 );++$i;?>
<dl class="last">
	<dt>
		<b class="t-tag cg"></b>
		<a href="<?php echo url('doc/doccatelist',array('id'=>$catevo['id'])); ?>" target="_blank" style="font-size:15px;"><?php echo $catevo['name']; ?>
		<span class="textright">更多<b class="fa fa-angle-right"></b></span>
		</a>
	</dt>
	<dd>
	 <?php if(is_array($catevo['child']) || $catevo['child'] instanceof \think\Collection || $catevo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $catevo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$subvo): $mod = ($i % 2 );++$i;?>
					<a href="<?php echo url('doc/doclist',array('zoneid'=>$catevo['id'],'cid'=>$subvo['id'])); ?>" target="_blank" class="log-xsend" ><?php echo $subvo['name']; ?>
                        </a>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
 </dd>
 <div class="xianshi"><ul>
 	 <?php if(is_array($catevo['child']) || $catevo['child'] instanceof \think\Collection || $catevo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $catevo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$subvo): $mod = ($i % 2 );++$i;?><li><a href="<?php echo url('doc/doclist',array('zoneid'=>$catevo['id'],'cid'=>$subvo['id'])); ?>" target="_blank" class="log-xsend" ><?php echo $subvo['name']; ?>
                        </a></li> <?php endforeach; endif; else: echo "" ;endif; ?></ul></div>
</dl>
<?php endforeach; endif; else: echo "" ;endif; ?>
</div>
 <div class="banner-con   ">
 <div id="slider" class="nivoSlider slide-bner clearfix "> 
 
 <div class="swiper-container">
  <div class="swiper-wrapper">

  <?php if(is_array($slideimgs) || $slideimgs instanceof \think\Collection || $slideimgs instanceof \think\Paginator): $i = 0; $__LIST__ = $slideimgs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
   <a href="<?php echo $vo['url']; ?>" class="swiper-slide" title="<?php echo $vo['title']; ?>"  target="_blank"><img src="<?php echo get_picture_url((isset($vo['cover_id']) && ($vo['cover_id'] !== '')?$vo['cover_id']:'0')); ?>" alt="<?php echo $vo['title']; ?>" title="<?php echo $vo['title']; ?>"  /></a> 
  <?php endforeach; endif; else: echo "" ;endif; ?>
  </div>
  <div class="button-prev">
  <b>上一页</b>
  
  </div>
    <div class="button-next">
    <b>下一页</b>
    </div>
</div>
 
   
    
</div>

<div class="topic">
<ul class="clearfix"><!-- htmlcs-disable -->  


<?php if(is_array($doczdrank) || $doczdrank instanceof \think\Collection || $doczdrank instanceof \think\Paginator): $i = 0; $__LIST__ = $doczdrank;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="clearfix <?php if($key == 0): ?>first<?php else: ?>second<?php endif; ?>"> 
<a href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" class="log-xsend" style="display:block;">  
<div class="tpc-img slide-bner-adv-ret">    
<img src="<?php echo get_picture_urlbysavename($vo['savename'],$vo['ext'],$vo['appkey']); ?>" alt="<?php echo $vo['title']; ?>" title="<?php echo $vo['title']; ?>"> </div> 
 <div class="tpc-brief"> 
 <div style="color:#000;padding:5px 0px;"><?php echo $vo['username']; if($vo['userstatus'] == 3): ?>&nbsp;&nbsp;
<span style="color:#ff720f" class="iconfont icon-vip"></span>
<?php else: ?>
&nbsp;&nbsp;&nbsp;<?php echo getusergrade($vo['grades']); endif; ?></div>
 <?php if($vo['userstatus'] == 3): ?>
 <div style="color: #555;font-size:12px;"><?php echo $vo['statusdes']; ?></div>
 <?php endif; ?>
 <h5 title="<?php echo $vo['title']; ?>"  <?php if($vo['userstatus'] == 3): ?>class="ellipsis"<?php else: ?>class="ellipsis-2" <?php endif; ?>><?php echo $vo['title']; ?></h5> 

 <span class="bg-index normal-btn hide">点击进入</span> </div> </a> </li>

<?php endforeach; endif; else: echo "" ;endif; ?>


   
       <!-- html-enable --></ul>
</div>
</div>


 <div class="user-info  ">
<div class="logined-wrap">
<div class="logined-doc-num">

<p class="num-tip" style="margin:0px;padding:5px 0px;"><?php echo \think\Config::get('WEB_SITE_TITLE'); ?>海量文档</p>
<p class="num" id="total-docnum" data-docnum="199,269,156">

 <?php if(is_array($countarr) || $countarr instanceof \think\Collection || $countarr instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($countarr) ? array_slice($countarr,0,3, true) : $countarr->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<span class="num<?php echo $vo; ?>" data-num="<?php echo $vo; ?>" ></span>
<?php endforeach; endif; else: echo "" ;endif; ?>

<b class="spr">,</b>
 <?php if(is_array($countarr) || $countarr instanceof \think\Collection || $countarr instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($countarr) ? array_slice($countarr,3,3, true) : $countarr->slice(3,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<span class="num<?php echo $vo; ?>" data-num="<?php echo $vo; ?>" ></span>
<?php endforeach; endif; else: echo "" ;endif; ?>
<b class="spr">,</b>
 <?php if(is_array($countarr) || $countarr instanceof \think\Collection || $countarr instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($countarr) ? array_slice($countarr,6,3, true) : $countarr->slice(6,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<span class="num<?php echo $vo; ?>" data-num="<?php echo $vo; ?>" ></span>
<?php endforeach; endif; else: echo "" ;endif; ?>
</p>
</div>
<div class="logined-user-info">


<?php if(session('member_info') != null): ?>


<div class="user-brief bg-index clearfix">
<div class="avatar">
<div>
<img class="user-icon" src="<?php echo getheadurl($userinfo['userhead']); ?>">
</div>
<a href="<?php echo url('user/index'); ?>" target="_blank" class="bg-avatar bg-index"></a></div>
<div class="name-task">
<p class="name">
<a href="<?php echo url('user/index'); ?>" class="name-link" title="rrertert700" target="_blank">
<?php echo $userinfo['nickname']; ?>
</a>


<b id="user-vip-ic" class="ic-vip-disable-small"></b>

<?php if($userinfo['status'] == 3): ?>
<span style="color:#ff720f" class="iconfont icon-vip"></span>
<span style="    position: absolute;
    right: 19px;
    top: 30px;
    font-size: 42px;color:red;" class="iconfont icon-renzheng-copy"></span>
<?php endif; ?>
</p>
<p class="dengji">
<?php if($userinfo['status'] == 3): ?>
<?php echo $userinfo['statusdes']; else: ?>
<?php echo getusergrade($userinfo['grades'],$userinfo['id']); endif; ?>
</p>
</div>
</div>
<div class="doc-info-wrap">
<div class="doc-num-info row">

<div class="col-md-6" style="border-right:1px solid #E8E8E8;">
<p><a href="<?php echo url('user/index'); ?>" target="_blank"><span class="num"><?php echo $userinfo['point']; ?></span><br><?php echo $pointname; ?></a></p>

</div>
<div class="col-md-6">
<p><a href="<?php echo url('user/index'); ?>" target="_blank"><span class="num"><?php echo $userdoccount; ?></span><br>公共文档</a></p>

</div>


</div>

</div>

<div class="text-center " style="padding:7px 15px;" >
<a class="btn btn-default btn-block logoutajax" data-url="<?php echo url('user/logout'); ?>" href="javascript:;">退出登录</a>
</div>
<?php if(session('member_info') != null): ?>
<p class="num-tip"><a class="btn btn-warning btn-block"  href="<?php echo url('doc/docupload'); ?>">
<i class="iconfont icon-upload " style="font-size:26px;"></i> 上传我的文档</a></p>

<div class="text-center"  ><a href="<?php echo url('article/index',array('id'=>2)); ?>">
新手入门</a></div>

<?php endif; else: ?>


<div class="text-center es-padding-r-10 es-padding-l-10">

<form class="form-horizontal "  id="loginform" data-url='<?php echo url("user/loginHandle"); ?>'>

<h4   class="active text-left es-font16 es-padding-t-10 es-padding-b-10"><span>文库账号登录</span></h4>

  <div class="form-group">
    
    <div class="col-sm-12">
      <input type="text" class="form-control" id="username" name="username" placeholder="用户名">
    </div>
  </div>
  <div class="form-group">
   
    <div class="col-sm-12">
      <input type="password" class="form-control" id="password" name="password" placeholder="密码">
    </div>
  </div>
    <?php if($yzm == 1): ?>


    <div class="form-group clearfix">
   
   
    <div class="col-sm-12">
      <input type="text" style="float:left;width:70px;margin-right:5px;" class="form-control" id="verify" name="verify" placeholder="验证码">
      <div>
   <img id="captcha" src="<?php echo url('User/captchaShow'); ?>" onclick="this.src='<?php echo url('User/captchaShow'); ?>?'+Math.random();" class="pull-left" style="height:40px;" />
    </div>
    </div>
  </div>
<?php endif; ?>
  <div class="form-group" style="margin-bottom:0px;">
    <div class="col-sm-12">
      <a id="submit" href="javascript:;" class="btn btn-default  btn-block loginajax">登 录</a>
      <div class="pull-right es-padding-10"><a style="color:#19A97B" href="<?php echo url('user/register'); ?>">快速注册</a></div>
    </div>
  </div>
</form>

</div>

<?php endif; ?>






</div>
</div>
</div>

 </div>
 
</div>
<div id="bd">

<div id="screen-bd" class="clearfix">
<div class="bd-layout">
<div class="row-2-0 crf-clf clearfix">
<ul class="unity-clsfy reco-category tab-cate clearfix">


<li class="big-team big-sec" >
<div class="inner-team">
<span>热点推荐</span>
<ul class="det-team">

 <?php if(is_array($hotdoclist) || $hotdoclist instanceof \think\Collection || $hotdoclist instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($hotdoclist) ? array_slice($hotdoclist,0,3, true) : $hotdoclist->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="lit-team">
<a class="ellipsis"  href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a>
<?php if($vo['create_time'] > (time()-24*60*60)): ?><span class="ui-bz-new-ic"></span><?php endif; endforeach; endif; else: echo "" ;endif; ?>

</li>
</ul>
</div>
</li>
<li class="big-team big-thr">
<div class="inner-team">
<span>精品文库</span>
<ul class="det-team ">
 <?php if(is_array($choicedoclist) || $choicedoclist instanceof \think\Collection || $choicedoclist instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($choicedoclist) ? array_slice($choicedoclist,0,3, true) : $choicedoclist->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="lit-team"><a class="ellipsis"  href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a>
<?php if($vo['create_time'] > (time()-24*60*60)): ?><span class="ui-bz-new-ic"></span><?php endif; ?>
</li>

<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</li>

<div class="verify-user pull-right"  style=" width: 326px;padding:10px;" >
<div class="notice-ad">
<h4><span class="more"><a href="<?php echo url('article/artlist',array('id'=>3)); ?>" target="_blank">更多</a></span>公告区</h4>
<ul class="notice-wrap">
 <?php if(is_array($gglist) || $gglist instanceof \think\Collection || $gglist instanceof \think\Paginator): $i = 0; $__LIST__ = $gglist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="ellipsis"  ><a href="<?php echo url('article/index',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</div>
</ul>
</div>
</div>

<div class="home-reward-content clearfix">
<div class="reward-main">
<div class="reward-h1">文档悬赏</div>
<div class="reward-main">
<div class="reward-initiate">
<div class="reward-h3">发起悬赏</div>
<div class="reward-find">
<h2><i class="re-icon-lb"></i>找不到需要的文档？</h2>
<p>发布悬赏任务请百万文库用户为你提供</p>
</div>
<div class="reward-search-content">
<p>已有<span class="p-em-tips"><?php echo $xscount; ?></span>用户收到悬赏文档</p>
<a class="btn btn-warning re-search-btn" href="<?php echo url('doc/docxs'); ?>" target="_blank"><span class="iconfont icon-wendang"></span><span>我想求文档</span></a>
</div>
</div>
<div class="reward-daily">
<div class="reward-h3">每日悬赏<a class="p-em-tips p-pl-18 log-xsend"  href="<?php echo url('doc/docxslist'); ?>" target="_blank">更多悬赏 &gt;</a>
<a class="btn btn-default btn-sm pull-right hide" href="javascript:void(0);">换一换</a>
</div>
<div class="reward-list-content">
<ul>

 <?php if(is_array($xslist) || $xslist instanceof \think\Collection || $xslist instanceof \think\Paginator): $i = 0; $__LIST__ = $xslist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li><a href="<?php echo url('doc/docxscon',array('id'=>$vo['id'])); ?>" target="_blank" class="log-xsend" ><i class="re-icon-xs">悬赏</i>
<p class="xs-page-docTitle"><?php echo $vo['title']; ?></p>
<p class="xs-page-ticket">赏金：<span class="p-em-tips"><?php echo $vo['score']; ?><?php echo $pointname; ?></span>
<span class="xs-page-sort"><i class="re-icon-sort"></i><?php echo $vo['tidname']; ?></span></p>
</a>
</li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</div>
</div>
</div>
<div class="reward-sidebar">
<div class="reward-h1">大家都在赚</div>
<div class="reward-lists">
<div class="reward-list-inner">
<ul id="reward-lists-ani" class="reward-lists-ani" style="top: 0px;">




<?php if(is_array($userxslist) || $userxslist instanceof \think\Collection || $userxslist instanceof \think\Paginator): $i = 0; $__LIST__ = $userxslist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

<li>
<a class="re-a-list log-xsend" href="<?php echo url('doc/docxscon',array('id'=>$vo['id'])); ?>" target="_blank">
<img class="rw-icon-user" src="<?php echo getheadurlbyid($vo['duid']); ?>">
<div class="re-list-docList">
<p class="re-list-docTitle"><?php echo getusernamebyid($vo['duid']); ?>完成了“<?php echo msubstr($vo['title'],0,5); ?>”任务 获得<?php echo $vo['score']; ?><?php echo $pointname; ?></p>
<p class="re-list-tips"><span><?php echo friendlyDate($vo['update_time']); ?></span><span class="p-em-tips p-fr-tips">+<?php echo $vo['score']; ?><?php echo $pointname; ?></span></p>
</div>
</a>
</li>
<?php endforeach; endif; else: echo "" ;endif; ?></ul>
</div>
</div>
</div>
</div>







<div class="row-2 verify-user clearfix" style="border-bottom:none;">
<div class="row-main">
<div class="main-con clearfix">
<h3>文库贡献者</h3>
<div class="verify-user-wrap clearfix">
<dl class="ver-dr">
<dt>
<span style="color: #C94946;">达人用户</span><b class="aw-t bg-index"></b>
</dt>
<dd>

<?php if(is_array($norzuserdoclist) || $norzuserdoclist instanceof \think\Collection || $norzuserdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $norzuserdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<div class="vuser-info clearfix">
<div class="avatar">
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank">
<img src="<?php echo getheadurl($vo['userhead']); ?>">
</a>
</div>
<div class="info">
<p class="author">
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank"><?php echo $vo['nickname']; ?></a>
<span class="level"><?php if($vo['userstatus'] == 3): ?>
<span style="color:#ff720f" class="iconfont icon-vip"></span>
<?php else: ?>
<?php echo getusergrade($vo['grades'],$vo['uid']); endif; ?></span>
<b class="ic-ver bg-index"></b>
</p>
<p><?php echo msubstr($vo['udes'],0,20); ?></p>
<p class="score">文档总评价

<?php if(is_array($norzuserdoclistarr) || $norzuserdoclistarr instanceof \think\Collection || $norzuserdoclistarr instanceof \think\Paginator): $i = 0; $__LIST__ = $norzuserdoclistarr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nvo): $mod = ($i % 2 );++$i;?>
<b class="ic-star bg-index <?php if($nvo == 2): ?>full<?php elseif($nvo == 1): ?>half<?php else: ?>empty<?php endif; ?>"></b>
<?php endforeach; endif; else: echo "" ;endif; ?>
<span class="score"><?php echo $vo['raty']; ?></span>
</p>



</div>
</div>
<div class="user-docinfo">
<div class="t-aw bg-index"></div>
<p>贡献文档:<span><?php echo $vo['dcount']; ?></span>篇 &nbsp;&nbsp;总下载量:<span><?php echo $vo['sumdown']; ?></span>次</p>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>



<ul class="rank-list">
<li class="title">贡献排行榜</li>
<?php if(is_array($zhounorzuserdoclist) || $zhounorzuserdoclist instanceof \think\Collection || $zhounorzuserdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $zhounorzuserdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li><span class="num"><?php echo $vo['dcount']; ?>份文档</span>
<span class="ui-idx <?php if($key == 0): ?>first<?php endif; ?>"><?php echo $key+1; ?></span>
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank" title="<?php echo $vo['nickname']; ?>"><?php echo $vo['nickname']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>

</ul>

</dd>
</dl>
<dl class="ver-p">
<dt>
<span style="color: #a00040;">认证用户
<b class="aw-t bg-index"></b>
</span>
</dt>
<dd>

<?php if(is_array($rzuserdoclist) || $rzuserdoclist instanceof \think\Collection || $rzuserdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $rzuserdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<div class="vuser-info clearfix">
<div class="avatar">
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank">
<img src="<?php echo getheadurl($vo['userhead']); ?>">
</a>
</div>
<div class="info">
<p class="author">
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank"><?php echo $vo['nickname']; ?></a>
<span class="level">
<?php if($vo['userstatus'] == 3): ?>
<span style="color:#ff720f" class="iconfont icon-vip"></span>
<?php else: ?>
<?php echo getusergrade($vo['grades'],$vo['uid']); endif; ?>


</span>&nbsp;
<b class="ic-ver bg-index"></b>
</p>
<p><?php echo msubstr($vo['udes'],0,20); ?></p>
<p class="score">文档总评价
<?php if(is_array($rzuserdoclistarr) || $rzuserdoclistarr instanceof \think\Collection || $rzuserdoclistarr instanceof \think\Paginator): $i = 0; $__LIST__ = $rzuserdoclistarr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nvo): $mod = ($i % 2 );++$i;?>
<b class="ic-star bg-index <?php if($nvo == 2): ?>full<?php elseif($nvo == 1): ?>half<?php else: ?>empty<?php endif; ?>"></b>
<?php endforeach; endif; else: echo "" ;endif; ?>
<span class="score"><?php echo $vo['raty']; ?></span>
</p>
<p><?php echo $vo['statusdes']; ?></p>
</div>
</div>
<div class="user-docinfo">
<div class="t-aw bg-index"></div>
<p>贡献文档:<span><?php echo $vo['dcount']; ?></span>篇 &nbsp;&nbsp;总下载量:<span><?php echo $vo['sumdown']; ?></span>次</p>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>


<ul class="rank-list">
<li class="title">贡献排行榜</li>
<?php if(is_array($zhourzuserdoclist) || $zhourzuserdoclist instanceof \think\Collection || $zhourzuserdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $zhourzuserdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li><span class="num"><?php echo $vo['dcount']; ?>份文档</span>
<span class="ui-idx <?php if($key == 0): ?>first<?php endif; ?>"><?php echo $key+1; ?></span>
<a href="<?php echo url('user/home',array('id'=>$vo['uid'])); ?>" target="_blank" title="<?php echo $vo['nickname']; ?>"><?php echo $vo['nickname']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>

</ul>

</dd>
</dl>
<dl>
<div class="ui-rank">
<h4 class="doc-rank-t" style="margin-top:0px;">最新文档
<span class="pull-right" style="font-size:12px;"><a href="<?php echo url('doc/docchoice',array('doctype'=>3)); ?>">更多</a></span>
</h4>
<ul>
 <?php if(is_array($newdoclist) || $newdoclist instanceof \think\Collection || $newdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $newdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="lane">

<span class="ui-idx <?php if($key == 0): ?>ui-idx-special<?php endif; ?>"><?php echo $key+1; ?></span>
<div class="book-info">
<h6>
<span class="num"><?php echo $vo['pageid']; ?>页</span>
<a class="ellipsis"  href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a>
</h6>
</div>
</li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</dl>
<dl class="ver-o hide">
<dt>
<a href="/org/index" target="_blank">机构专区
<b class="aw-t bg-index"></b>
</a>
</dt>
<dd>
<div class="vuser-info clearfix">
<div class="avatar">
<a href="" target="_blank">
<img src="#">
</a>
</div>
<div class="info">
<p class="author">
<a href="#" target="_blank">维普网</a><span class="level">10级</span><b class="ic-ver bg-index"></b>
</p>
<p>中文科技期刊论文搜索平台</p>
<p class="score">文档总评价<b class="ic-star bg-index full"></b>
<b class="ic-star bg-index full"></b>
<b class="ic-star bg-index full"></b>
<b class="ic-star bg-index full"></b>
<b class="ic-star bg-index full"></b>
<span class="score">5.0</span>
</p>
</div>
</div>
<div class="user-docinfo">
<div class="t-aw bg-index"></div>
<p>贡献文档:<span>10190540</span>篇 &nbsp;&nbsp;总下载量:<span>89367</span>次</p>
</div>
<ul class="rank-list">
<li class="title">本周排行榜</li>
<li><span class="num">8653份文档</span><span class="ui-idx first">1</span><a href="#" target="_blank" title="龙源期刊网">龙源期刊网</a></li>
<li><span class="num">6801份文档</span><span class="ui-idx ">2</span><a href="#" target="_blank" title="精品学习网">精品学习网</a></li>
<li><span class="num">2130份文档</span><span class="ui-idx ">3</span><a href="#" target="_blank" title="华图教育网">华图教育网</a></li>
<li><span class="num">1890份文档</span><span class="ui-idx ">4</span><a href="#" target="_blank" title="E智网">E智网</a></li>
<li><span class="num">1508份文档</span><span class="ui-idx ">5</span><a href="#" target="_blank" title="教育联展网">教育联展网</a></li>
</ul>

</dd>
</dl>
</div>
</div>
</div>
<div class="row-side">

<div class="ui-rank" style="margin-top:60px;">
<h4 class="doc-rank-t">热门文档
<span class="pull-right"  style="font-size:12px;"><a href="<?php echo url('doc/docchoice',array('doctype'=>0)); ?>">更多</a></span>
</h4>
<ul>
 <?php if(is_array($hotdoclist) || $hotdoclist instanceof \think\Collection || $hotdoclist instanceof \think\Paginator): $i = 0; $__LIST__ = $hotdoclist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
<li class="lane">

<span class="ui-idx <?php if($key == 0): ?>ui-idx-special<?php endif; ?>"><?php echo $key+1; ?></span>
<div class="book-info">
<h6>
<span class="num"><?php echo $vo['view']; ?>次</span>
<a class="ellipsis"  href="<?php echo url('doc/doccon',array('id'=>$vo['id'])); ?>" target="_blank" title="<?php echo $vo['title']; ?>"><?php echo $vo['title']; ?></a>
</h6>
</div>
</li>
<?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</div>
</div>
</div>

</div> 

  

  
  
<div id="ft"><div class="footer"><p>Copyright © 2017 imzaker.com 版权所有  <?php echo \think\Config::get('web_site_icp'); ?></p><?php echo html_entity_decode(\think\Config::get('web_site_footer')); ?></div></div>
<script type="text/javascript" src="__PUBLIC__/js/layer/layer.js"></script>
<script type="text/javascript" src="__PUBLIC__/js/common.js"></script>

  <script type="text/javascript" src="__PUBLIC__/js/swiper/swiper-3.4.2.jquery.min.js"></script>
  
<!--页面JS脚本-->

    <script>
    $(function() { 
    	
    	
    	$(function(){
    		
    		$('dl.last').mouseenter(function(){
    			
    			$('.xianshi').hide();
    			
    			$(this).find('.xianshi').show();
    			
    		});
	        $('.cate').mouseleave(function(){
    			
    			$(this).find('.xianshi').hide();
    			
    		});
    	})
    	
    	
    	
    	
    	var mySwiper = new Swiper('.swiper-container', {
    		autoplay: 3000,//可选选项，自动滑动
    		prevButton:'.button-prev',
    		nextButton:'.button-next',
    		effect : 'coverflow',
    		loop:true,
    		coverflow: {
                rotate: 30,
                stretch: 10,
                depth: 60,
                modifier: 2,
                slideShadows : true
            }
    	});
    	$("#slider").mouseenter(function(){
    		$('.swiper-container .button-prev').show();
			$('.swiper-container .button-next').show();
    		mySwiper.stopAutoplay();}).mouseleave(function(){ 
    			$('.swiper-container .button-prev').hide();
    			$('.swiper-container .button-next').hide();
    			mySwiper.startAutoplay();});
    		
   }); 
    </script>
      
</body>
</html>